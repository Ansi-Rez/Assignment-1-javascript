//Question 1:
var curyear = 2021;

var yeararray = [];
/*This for loop changes the number variable to a string 
and then feeds it into the array one by one using charAt.
However it is cast to a number before entering the array.
*/
for(let i = 0; i < curyear.toString().length; i++)
{
    let cy = curyear.toString();

    yeararray[i] = Number(cy.charAt(i));
}

//This for loop prints the individual digits of the array one by one.
for(let c = 0; c < yeararray.length; c++)
{
    console.log(yeararray[c]);
}

//Question 2:
var arr = ['M','I','K','E'];
//Here the Math.random method is used to create a psuedorandom number
//The number is inclusive of 0 but not 4.
//The number is also rounded to the lowest possible whole number by the Math.floor method
var n = Math.floor(Math.random(0) * arr.length);

//I used the splice method to remove n characters from the left of the array.
arr.splice(0,n);

console.log(arr);

//Question 3:
var arr = [false, true, 1, 0,null, 'Mike','',9];
/*This for loop has an if statement that performs coercion to
check if a value from the array is equal to false.
If it returns true a splice method is used to remove that element
from the array.
*/
for(let i = 0; i < arr.length; i++)
{
    if(arr[i] == false)
    {
        arr.splice(i,1);
    }
}

console.log(arr);

//Question 4:
var arr = ['M', 'I', 'K', 'E'];

//Here the Math.random method is used to create a psuedorandom number
//The number is inclusive of 1 but not 4.
//The number is also rounded to the lowest possible whole number by the Math.floor method
var n = Math.floor(Math.random(1) * arr.length);

/*This for loop uses n to limit the amount of times the loop happens
and in each loop a value is removed from the array and pushed to the back
*/
for(let c = 0; c < n; c++)
{
    arr.push(arr.shift());
}

console.log(arr);